const motsATrouver = [
    null,
    null,
    null,
    null,
    null,
    null,
    [
        "footzy",
    ]
]